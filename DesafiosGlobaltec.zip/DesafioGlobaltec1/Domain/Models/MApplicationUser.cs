﻿/*
* Chamada da classe que cria os usuarios da aplicação
*/
using Microsoft.AspNetCore.Identity;

namespace DesafioGlobaltec.Domain.Models {
    public class ApplicationUser : IdentityUser {
        //
    }
}